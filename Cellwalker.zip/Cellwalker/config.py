
config = {"python_environment":"C:\\Users\\harsh\\anaconda3\\envs\\cellwalker-blender\\Lib\\site-packages\\"}
