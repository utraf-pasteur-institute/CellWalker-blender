Download this folder and import it like a addon zip in Blender
